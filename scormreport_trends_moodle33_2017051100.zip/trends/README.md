moodle-scormreport_trendsreport
===============================

Scrom Trends Report for Moodle

Installation Instruction
=====================

* Extrat the folder from zip and copy it to your moodle/mod/scorm/report/trends
* Login as admin and go to site admin>notifications and install


Maturity
====================
STABLE


Change log
=====================
* 2013050700 - First public release - 1.0
* 2014032000 - Release for Moodle 2.7 - 1.1
* 2014051204 - Release for Moodle 2.8 - 1.2 (Use autoloading, code cleanup, remove reportlib.php)
* 2017013100 - Major code cleanup, remove deprecated stuff, travis support, fixed travis detected issues - 1.3
* 2017032100 - Minor code style fixes - 1.4
* 2017051100 - Release for Moodle 3.3 - 1.5

About Author
=====================
Ankit Kumar Agarwal

Moodle HQ developer

https://github.com/ankitagarwal

http://ankitkumaragarwal.com

Credits
=====================
Thanks to Dan Marsden for his guidance during the whole Scorm report framework rewrite.

License
=====================

GPL 3 or later

Report bugs
=====================
<https://github.com/ankitagarwal/moodle-scormreport_trends/issues>
